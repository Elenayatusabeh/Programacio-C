#include <stdio.h>
#include <stdlib.h>
/*Algorisme que demana la mida d'un rectangle i en calcula l'�rea.*/

int main (void)
{
    int alt, llar, area;
    printf("Introdueix l'altura del rectangle en cm\n");
    scanf("%d",&alt);
    printf("Introdueix la llargada del rectangle en cm\n");
    scanf("%d",&llar);
    area=alt*llar;
    printf("L'area del rectangle es %d cm2 \n",area);

}
