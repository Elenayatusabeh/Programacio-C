#include <stdio.h>
#include <stdlib.h>
/*Algorisme que llegeix 3 nombres i els mostra ordenats de major a menor. */


int main (void)
{
    int n1, n2, n3, b1, b2, b3;
    printf("Introdueix el primer nombre");
    scanf("%d",&n1);
    printf("Introdueix el segon nombre");
    scanf("%d",&n2);
    printf("Introdueix el tercer nombre");
    scanf("%d",&n3);
    if(n1>n2)
    {
        if(n1>n3)
        {
            b1=n1;
            if(n2>n3)
            {
                b2=n2;
                b3=n3;
            }

            else
            {
                b2=n3;
                b3=n2;
            }
        }
        else
        {
            b1=n3;
            b2=n1;
            b3=n2;
        }

    }
    else
    {
        if(n2>n3)
        {
            b1=n2;
            if(n1>n3)
            {
                b2=n1;
                b3=n3;
            }
            else
            {
                b2=n3;
                b3=n1;
            }
        }
        else
        {
            b1=n3;
            b2=n2;
            b3=n1;
        }
    }
    printf("El 1er es %d, el 2on es %d i el 3er es %d",b1,b2,b3);
}


