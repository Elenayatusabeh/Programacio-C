#include <stdio.h>
#include <stdlib.h>
/*Algorisme que llegeix un nombre i ens diu si �s m�ltiple de dos, o de tres, o de cap d'ells.*/

int main (void)
{
    int n;
    printf("Introdueix un nombre");
    scanf("%d",&n);
    if(n%2!=0&&n%3!=0){
        printf("El numero no es divisible ni per 2 ni per 3 \n");
    }
    else{
        if(n%2==0){
            printf("El numero es divisible per 2 \n");
        }
        else {
            printf("El numero no es divisible per 2 \n");
        }
        if(n%3==0){
            printf("El numero es divisible per 3 \n");
        }
        else {
            printf("El numero no es divisible per 3 \n");
        }
    }
}
