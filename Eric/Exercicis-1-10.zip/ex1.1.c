#include <stdio.h>
#include <stdlib.h>
/*Algorisme que llegeix un nombre i ens indica si �s major que 10 o no.*/

int main (void)
{
    int n;
    printf("Introdueix un nombre");
    scanf("%d",&n);
    n=n*3;
    printf("El resultat es %d",n);
}
