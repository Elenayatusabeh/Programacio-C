#include <stdio.h>
#include <stdlib.h>
/*10.	Algorisme que llegeix dos nombres enters positius i diferents, i ens diu si el major �s m�ltiple del menor, o el que �s
 al mateix, si el menor �s divisor del major.*/

int main (void)
{
    int n1, n2;
    printf("Introdueix un nombre ");
    scanf("%d",&n1);
    printf("Introdueix un segon nombre ");
    scanf("%d",&n2);
    if(n1>n2){
            if(n1%n2==0){
                printf("%d es multiple de %d\n",n1,n2);
            }
            else{
                printf("%d no es multiple de %d\n",n1,n2);
            }

    }
    else{
        if(n2>n1){
                if(n2%n1==0){
                    printf("%d es multiple de %d\n",n2,n1);
                }
                else{
                    printf("%d no es multiple de %d\n",n2,n1);

                }

        }
        else{

            printf("Els dos nombres son iguals \n");

        }
    }
}

