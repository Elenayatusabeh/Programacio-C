#include <stdio.h>
#include <stdlib.h>
/*Algorisme que llegeix un nombre i ens indica si �s major que 10 o no.*/

int main (void)
{
    int n;
    printf("Introdueix un nombre");
    scanf("%d",&n);
    if(n>10)
    {
        printf("El nombre es major de 10\n");
    }
    else
    {
        printf("El nombre no es major de 10\n");
    }
}
