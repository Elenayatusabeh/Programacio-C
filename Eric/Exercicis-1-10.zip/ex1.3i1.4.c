#include <stdio.h>
#include <stdlib.h>
/*Algorisme que llegeix un nombre i ens indica si �s major que 10 o no.*/

int main (void)
{
    int n1, n2;
    printf("Introdueix el primer nombre");
    scanf("%d",&n1);
    printf("Introdueix el segon nombre");
    scanf("%d",&n2);

    if(n1>n2)
    {
        printf("El major nombre es %d",n1);
    }
    else
    {
        if(n2>n1)
        {
            printf("El major nombre es %d",n2);
        }
        else
        {
            printf("Els dos nombres son iguals");
        }
    }

}
