#include <stdio.h>
#include <stdlib.h>
/*Algorisme que llegeix 3 nombres i diu quin �s el major*/

int main (void)
{
    int n1, n2, n3;
    printf("Introdueix el primer nombre");
    scanf("%d",&n1);
    printf("Introdueix el segon nombre");
    scanf("%d",&n2);
    printf("Introdueix el tercer nombre");
    scanf("%d",&n3);
    if(n1>n2)
    {
        if(n1>n3)
        {
            printf("El major nombre es %d",n1);
        }
    }
    else
    {
        if(n2>n3)
        {
            printf("El major nombre es %d",n2);
        }
        else
        {
            printf("El major nombre es %d",n3);
        }
    }

}
