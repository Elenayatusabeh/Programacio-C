#include <stdio.h>
#include <stdlib.h>
/*Algorisme que llegeix dos nombres i calcula la seva suma, resta, multiplicaci� i divisi� reals. */

int main (void)
{
    float n1, n2, sum, res, div, mul;
    printf("Introdueix un nombre\n");
    scanf("%f",&n1);
    printf("Introdueix un segon nombre\n");
    scanf("%f",&n2);
    sum=n1+n2;
    res=n1-n2;
    div=n1/n2;
    mul=n1*n2;
    printf("El resultat de la suma es %f \n",sum);
    printf("El resultat de la resta es %f \n",res);
    printf("El resultat de la divisio es %f \n",div);
    printf("El resultat de la multiplicacio es %f \n",mul);
}
